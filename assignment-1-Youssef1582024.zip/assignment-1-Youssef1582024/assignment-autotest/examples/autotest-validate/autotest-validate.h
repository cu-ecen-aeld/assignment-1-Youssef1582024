#include <stdbool.h>

bool this_function_returns_true();
bool this_function_returns_false();
