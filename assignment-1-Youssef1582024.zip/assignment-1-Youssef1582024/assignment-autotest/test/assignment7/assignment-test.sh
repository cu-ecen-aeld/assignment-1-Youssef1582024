#!/bin/bash

testdir=$1
./unit-test.sh
